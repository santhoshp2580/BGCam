# 📹 BGCam — Background Video Recorder

A professional Android app that records video **even when the screen is OFF**, with 1080p max quality, video stabilization, and real-time face detection.

---

## ✅ Features

| Feature | Details |
|---|---|
| **Background Recording** | Records video with screen completely off using Camera2 + Foreground Service |
| **Max 1080p Quality** | Selectable: 1080p / 720p / 480p with high-bitrate H.264 encoding |
| **Video Stabilization** | Software + hardware stabilization via Camera2 & MediaRecorder APIs |
| **Face Detection** | Real-time ML Kit face detection with bounding boxes, smile/eye tracking, and ID labels |
| **Front & Back Camera** | Toggle anytime from main screen or camera view |
| **Flash / Torch** | Toggle torch while recording |
| **Gallery** | In-app gallery to play, share, or delete recordings |
| **Notification Control** | Persistent notification with "Stop Recording" action button |
| **Wake Lock** | Keeps CPU alive during background recording (screen-off safe) |
| **Audio** | 44.1 kHz AAC stereo at 192 kbps |

---

## 🏗️ Project Structure

```
BackgroundCamera/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/bgcam/app/
│   │   │   ├── activities/
│   │   │   │   ├── MainActivity.java        ← Main dashboard
│   │   │   │   ├── CameraActivity.java      ← Live preview + face detect + recording
│   │   │   │   └── GalleryActivity.java     ← Browse/play/share/delete videos
│   │   │   ├── services/
│   │   │   │   └── BackgroundRecordingService.java  ← Core Camera2 background service
│   │   │   ├── camera/
│   │   │   │   └── FaceOverlayView.java     ← Custom view for face boxes
│   │   │   └── utils/
│   │   │       ├── PreferenceManager.java   ← SharedPreferences wrapper
│   │   │       ├── FileUtils.java           ← Video file management
│   │   │       ├── RecordingState.java      ← Shared recording state
│   │   │       └── BootReceiver.java        ← Boot completed receiver
│   │   └── res/
│   │       ├── layout/                      ← All XML layouts
│   │       ├── drawable/                    ← Icons & backgrounds
│   │       ├── values/                      ← Colors, strings, themes, arrays
│   │       └── xml/file_paths.xml           ← FileProvider paths
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🛠️ How to Build

### Prerequisites
- **Android Studio Hedgehog (2023.1.1)** or newer
- **JDK 17** (bundled with Android Studio)
- Android SDK **API 26+** installed
- A physical Android device (camera won't work on emulator)

### Steps

1. **Open the project**
   ```
   Android Studio → File → Open → select the BackgroundCamera/ folder
   ```

2. **Sync Gradle**
   - Click "Sync Now" when prompted, or go to **File → Sync Project with Gradle Files**

3. **Connect your device**
   - Enable **Developer Options** and **USB Debugging** on your phone
   - Connect via USB

4. **Run the app**
   - Click ▶ **Run** (Shift+F10) and select your device
   - The app will be installed and launched automatically

5. **Or build an APK**
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

---

## 📱 Permissions Required

The app will ask for these on first launch:

| Permission | Why |
|---|---|
| `CAMERA` | To record video |
| `RECORD_AUDIO` | For audio in recordings |
| `POST_NOTIFICATIONS` | To show recording notification (Android 13+) |
| `READ_MEDIA_VIDEO` | To browse recordings in gallery (Android 13+) |
| `FOREGROUND_SERVICE_CAMERA` | To use camera in background (Android 14+) |
| `WAKE_LOCK` | Keep CPU running when screen is off |

---

## 📂 Where Videos Are Saved

- **Android 10+**: `/Android/data/com.bgcam.app/files/Movies/BGCam/`
- **Android 9 and below**: `/sdcard/Movies/BGCam/`

All videos are named like: `BGCam_20240328_143022.mp4`

---

## ⚙️ Video Quality Settings

| Setting | Resolution | Bitrate | File size ~10 min |
|---|---|---|---|
| 1080p (Max) | 1920×1080 | 16 Mbps | ~1.2 GB |
| 720p (HD)   | 1280×720  | 8 Mbps  | ~600 MB |
| 480p (SD)   | 720×480   | 4 Mbps  | ~300 MB |

---

## 🧠 How Background Recording Works

```
User taps "Start Background Recording"
        ↓
MainActivity → starts BackgroundRecordingService as Foreground Service
        ↓
Service acquires WakeLock (keeps CPU running even with screen off)
        ↓
Camera2 API opens camera → creates MediaRecorder surface
        ↓
CaptureSession starts with:
  - Auto-focus (CONTROL_AF_MODE_CONTINUOUS_VIDEO)
  - Auto-exposure (CONTROL_AE_MODE_ON)
  - Video stabilization (CONTROL_VIDEO_STABILIZATION_MODE_ON)
        ↓
MediaRecorder writes H.264/AAC → .mp4 file
        ↓
User taps "Stop" in notification OR returns to app
        ↓
Recording stops → file saved → MediaScanner notified → gallery updated
```

---

## 🔍 Face Detection Details

- Uses **Google ML Kit Face Detection** (on-device, no internet needed)
- Runs on a background thread via `ImageAnalysis` use-case
- Draws **corner-bracket bounding boxes** on detected faces
- Shows **emoji indicators**: 😊 for smile, 😉 for closed eye
- Displays **tracking ID** per face for multi-face scenarios
- Works in **both front and back camera** (mirrored for front)

---

## 🐛 Troubleshooting

| Problem | Solution |
|---|---|
| Camera won't open in background | On some phones (Xiaomi, OPPO, Samsung), go to **Settings → Battery → BGCam → No restrictions** |
| Recording stops when screen off | Grant **"Allow background activity"** in app settings |
| No audio in recording | Make sure microphone permission is granted |
| Video not appearing in gallery | Try opening the app's Gallery tab — it shows app-specific files |
| Build fails on `foregroundServiceType` | Make sure your compileSdk and targetSdk are **34** |

---

## 📄 License

MIT License — free to use, modify, and distribute.

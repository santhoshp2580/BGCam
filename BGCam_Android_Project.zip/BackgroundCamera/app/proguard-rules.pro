# BGCam ProGuard Rules
-keep class com.bgcam.app.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class androidx.camera.** { *; }
-dontwarn com.google.mlkit.**
-dontwarn androidx.camera.**

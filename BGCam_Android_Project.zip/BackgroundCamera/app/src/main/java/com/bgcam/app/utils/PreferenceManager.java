package com.bgcam.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static final String PREF_NAME = "bgcam_prefs";
    private static final String KEY_FRONT_CAMERA   = "use_front_camera";
    private static final String KEY_FACE_DETECT     = "face_detection";
    private static final String KEY_STABILIZATION   = "stabilization";
    private static final String KEY_QUALITY_INDEX   = "quality_index";

    private final SharedPreferences prefs;

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isUseFrontCamera() { return prefs.getBoolean(KEY_FRONT_CAMERA, false); }
    public void setUseFrontCamera(boolean value) { prefs.edit().putBoolean(KEY_FRONT_CAMERA, value).apply(); }

    public boolean isFaceDetectionEnabled() { return prefs.getBoolean(KEY_FACE_DETECT, true); }
    public void setFaceDetectionEnabled(boolean value) { prefs.edit().putBoolean(KEY_FACE_DETECT, value).apply(); }

    public boolean isStabilizationEnabled() { return prefs.getBoolean(KEY_STABILIZATION, true); }
    public void setStabilizationEnabled(boolean value) { prefs.edit().putBoolean(KEY_STABILIZATION, value).apply(); }

    /** 0 = 1080p (max), 1 = 720p, 2 = 480p */
    public int getQualityIndex() { return prefs.getInt(KEY_QUALITY_INDEX, 0); }
    public void setQualityIndex(int index) { prefs.edit().putInt(KEY_QUALITY_INDEX, index).apply(); }
}

package com.bgcam.app.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.util.Size;
import android.view.Surface;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.bgcam.app.R;
import com.bgcam.app.activities.MainActivity;
import com.bgcam.app.utils.FileUtils;
import com.bgcam.app.utils.PreferenceManager;
import com.bgcam.app.utils.RecordingState;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

/**
 * Foreground Service that records video using Camera2 API.
 * Continues recording even when the screen is OFF.
 */
public class BackgroundRecordingService extends Service {

    private static final String TAG = "BGRecordingService";
    public static final String ACTION_START = "ACTION_START_RECORDING";
    public static final String ACTION_STOP  = "ACTION_STOP_RECORDING";
    private static final String CHANNEL_ID   = "bgcam_recording_channel";
    private static final int    NOTIF_ID     = 1001;

    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private MediaRecorder mediaRecorder;
    private SurfaceTexture dummyTexture;
    private Surface dummySurface;
    private PowerManager.WakeLock wakeLock;
    private PreferenceManager prefs;
    private File outputFile;
    private boolean isRecording = false;

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new PreferenceManager(this);
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;

        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            startForegroundWithNotification();
            acquireWakeLock();
            openCamera();
        } else if (ACTION_STOP.equals(action)) {
            stopRecordingAndCleanup();
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        stopRecordingAndCleanup();
        super.onDestroy();
    }

    // ─── Notification ─────────────────────────────────────────────────────────

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Background Recording",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows when video is being recorded in background");
            channel.setSound(null, null);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void startForegroundWithNotification() {
        Intent stopIntent = new Intent(this, BackgroundRecordingService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPendingIntent = PendingIntent.getActivity(
            this, 1, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📹 Recording in Background")
            .setContentText("Tap to open app • Tap Stop to end recording")
            .setSmallIcon(R.drawable.ic_record_small)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(R.drawable.ic_stop, "Stop Recording", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();

        startForeground(NOTIF_ID, notification);
    }

    // ─── Wake Lock ────────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "BGCam::RecordingWakeLock"
        );
        wakeLock.acquire(3 * 60 * 60 * 1000L); // max 3 hours
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            wakeLock = null;
        }
    }

    // ─── Camera2 ─────────────────────────────────────────────────────────────

    private void openCamera() {
        try {
            String cameraId = getCameraId();
            if (cameraId == null) {
                Log.e(TAG, "No suitable camera found");
                stopSelf();
                return;
            }
            cameraManager.openCamera(cameraId, cameraStateCallback, null);
        } catch (CameraAccessException | SecurityException e) {
            Log.e(TAG, "Cannot open camera", e);
            stopSelf();
        }
    }

    private String getCameraId() throws CameraAccessException {
        boolean useFront = prefs.isUseFrontCamera();
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
            Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
            if (facing != null) {
                if (useFront && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
                if (!useFront && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
            }
        }
        return cameraManager.getCameraIdList()[0];
    }

    private final CameraDevice.StateCallback cameraStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice device) {
            cameraDevice = device;
            setupMediaRecorder();
            createCaptureSession();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice device) {
            device.close();
            cameraDevice = null;
        }

        @Override
        public void onError(@NonNull CameraDevice device, int error) {
            Log.e(TAG, "Camera error: " + error);
            device.close();
            cameraDevice = null;
            stopSelf();
        }
    };

    // ─── MediaRecorder ────────────────────────────────────────────────────────

    private void setupMediaRecorder() {
        outputFile = FileUtils.createVideoFile(this);
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setOutputFile(outputFile.getAbsolutePath());

        // Quality settings
        Size videoSize = getVideoSize();
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
        mediaRecorder.setVideoFrameRate(30);
        mediaRecorder.setVideoEncodingBitRate(getBitRate(videoSize));
        mediaRecorder.setAudioEncodingBitRate(192000);
        mediaRecorder.setAudioSamplingRate(44100);

        // Stabilization hint
        if (prefs.isStabilizationEnabled()) {
            mediaRecorder.setVideoStabilizationEnabled(true);
        }

        try {
            mediaRecorder.prepare();
        } catch (IOException e) {
            Log.e(TAG, "MediaRecorder prepare failed", e);
        }
    }

    private Size getVideoSize() {
        try {
            String cameraId = getCameraId();
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = chars.get(
                CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] sizes = map.getOutputSizes(MediaRecorder.class);
                int qualityIdx = prefs.getQualityIndex();
                if (qualityIdx == 0) {
                    // Find best ≤ 1920x1080
                    for (Size s : sizes) {
                        if (s.getWidth() <= 1920 && s.getHeight() <= 1080) return s;
                    }
                } else if (qualityIdx == 1) {
                    // 720p
                    for (Size s : sizes) {
                        if (s.getWidth() <= 1280 && s.getHeight() <= 720) return s;
                    }
                } else {
                    // 480p
                    for (Size s : sizes) {
                        if (s.getWidth() <= 720 && s.getHeight() <= 480) return s;
                    }
                }
                if (sizes.length > 0) return sizes[0];
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Cannot get video sizes", e);
        }
        return new Size(1920, 1080);
    }

    private int getBitRate(Size size) {
        int pixels = size.getWidth() * size.getHeight();
        if (pixels >= 1920 * 1080) return 16_000_000; // 16 Mbps for 1080p
        if (pixels >= 1280 * 720)  return  8_000_000; // 8 Mbps for 720p
        return 4_000_000;                              // 4 Mbps for 480p
    }

    // ─── Capture Session ─────────────────────────────────────────────────────

    private void createCaptureSession() {
        if (cameraDevice == null || mediaRecorder == null) return;

        // Dummy texture surface to satisfy Camera2 preview requirement
        dummyTexture = new SurfaceTexture(1);
        dummyTexture.setDefaultBufferSize(640, 480);
        dummySurface = new Surface(dummyTexture);

        Surface recorderSurface = mediaRecorder.getSurface();

        try {
            cameraDevice.createCaptureSession(
                Arrays.asList(dummySurface, recorderSurface),
                new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigured(@NonNull CameraCaptureSession session) {
                        captureSession = session;
                        startRecordingCapture(session, recorderSurface);
                    }

                    @Override
                    public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                        Log.e(TAG, "Capture session configure failed");
                        stopSelf();
                    }
                }, null
            );
        } catch (CameraAccessException e) {
            Log.e(TAG, "createCaptureSession failed", e);
        }
    }

    private void startRecordingCapture(CameraCaptureSession session, Surface recorderSurface) {
        try {
            CaptureRequest.Builder builder =
                cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            builder.addTarget(dummySurface);
            builder.addTarget(recorderSurface);

            // Auto-focus
            builder.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);

            // Auto exposure
            builder.set(CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON);

            // Video stabilization
            if (prefs.isStabilizationEnabled()) {
                builder.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
            }

            session.setRepeatingRequest(builder.build(), null, null);
            mediaRecorder.start();
            isRecording = true;
            RecordingState.setRecording(true);
            Log.d(TAG, "Background recording started → " + outputFile.getAbsolutePath());
        } catch (CameraAccessException e) {
            Log.e(TAG, "Start capture failed", e);
        }
    }

    // ─── Stop & Cleanup ───────────────────────────────────────────────────────

    private void stopRecordingAndCleanup() {
        if (isRecording) {
            try {
                if (captureSession != null) captureSession.stopRepeating();
            } catch (CameraAccessException | IllegalStateException e) {
                Log.w(TAG, "Stop repeating: " + e.getMessage());
            }
            try {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
            } catch (RuntimeException e) {
                Log.w(TAG, "MediaRecorder stop: " + e.getMessage());
                if (outputFile != null) outputFile.delete();
                outputFile = null;
            }
            isRecording = false;
            RecordingState.setRecording(false);

            if (outputFile != null && outputFile.exists()) {
                FileUtils.scanMediaFile(this, outputFile);
                Log.d(TAG, "Video saved: " + outputFile.getAbsolutePath());
            }
        }

        if (captureSession != null) { captureSession.close(); captureSession = null; }
        if (cameraDevice != null)   { cameraDevice.close(); cameraDevice = null; }
        if (dummySurface != null)   { dummySurface.release(); }
        if (dummyTexture != null)   { dummyTexture.release(); }

        releaseWakeLock();
        stopForeground(true);
        stopSelf();
    }
}

package com.bgcam.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bgcam.app.R;
import com.bgcam.app.databinding.ActivityGalleryBinding;
import com.bgcam.app.utils.FileUtils;
import com.bumptech.glide.Glide;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GalleryActivity extends AppCompatActivity {

    private ActivityGalleryBinding binding;
    private VideoAdapter adapter;
    private List<File> videoFiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGalleryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        loadVideos();
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVideos();
    }

    private void loadVideos() {
        videoFiles = FileUtils.getAllRecordedVideos(this);
        if (videoFiles.isEmpty()) {
            binding.rvVideos.setVisibility(View.GONE);
            binding.tvEmpty.setVisibility(View.VISIBLE);
        } else {
            binding.rvVideos.setVisibility(View.VISIBLE);
            binding.tvEmpty.setVisibility(View.GONE);
            adapter = new VideoAdapter(videoFiles);
            binding.rvVideos.setLayoutManager(new GridLayoutManager(this, 2));
            binding.rvVideos.setAdapter(adapter);
        }
        binding.tvCount.setText(videoFiles.size() + " video(s)");
    }

    private void playVideo(File file) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "video/mp4");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Play video with..."));
    }

    private void shareVideo(File file) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("video/mp4");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Share video"));
    }

    private void deleteVideo(File file, int position) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Video?")
            .setMessage("Delete " + file.getName() + "?")
            .setPositiveButton("Delete", (d, w) -> {
                if (file.delete()) {
                    videoFiles.remove(position);
                    adapter.notifyItemRemoved(position);
                    if (videoFiles.isEmpty()) {
                        binding.rvVideos.setVisibility(View.GONE);
                        binding.tvEmpty.setVisibility(View.VISIBLE);
                    }
                    binding.tvCount.setText(videoFiles.size() + " video(s)");
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancel", null).show();
    }

    class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VH> {
        final List<File> files;
        VideoAdapter(List<File> files) { this.files = files; }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_video, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            File f = files.get(position);
            Glide.with(holder.itemView.getContext())
                .load(f)
                .centerCrop()
                .placeholder(R.drawable.ic_video_placeholder)
                .into(holder.thumbnail);
            long sizeKb = f.length() / 1024;
            String size = sizeKb > 1024 ? (sizeKb / 1024) + " MB" : sizeKb + " KB";
            String date = new SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
                .format(new Date(f.lastModified()));
            holder.tvName.setText(f.getName());
            holder.tvInfo.setText(date + " • " + size);
            holder.itemView.setOnClickListener(v -> playVideo(f));
            holder.btnShare.setOnClickListener(v -> shareVideo(f));
            holder.btnDelete.setOnClickListener(v -> deleteVideo(f, holder.getAdapterPosition()));
        }

        @Override
        public int getItemCount() { return files.size(); }

        class VH extends RecyclerView.ViewHolder {
            ImageView thumbnail, btnShare, btnDelete;
            TextView tvName, tvInfo;
            VH(@NonNull View v) {
                super(v);
                thumbnail = v.findViewById(R.id.iv_thumbnail);
                btnShare  = v.findViewById(R.id.btn_share);
                btnDelete = v.findViewById(R.id.btn_delete);
                tvName    = v.findViewById(R.id.tv_name);
                tvInfo    = v.findViewById(R.id.tv_info);
            }
        }
    }
}

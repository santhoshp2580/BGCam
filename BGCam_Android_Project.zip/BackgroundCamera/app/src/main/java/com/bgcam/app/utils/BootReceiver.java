package com.bgcam.app.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives BOOT_COMPLETED so the app can restart recording if it was active before reboot. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // No-op by default. Extend if you want auto-start on boot.
    }
}

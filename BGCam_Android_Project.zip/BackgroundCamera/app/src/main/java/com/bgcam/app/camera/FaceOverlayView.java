package com.bgcam.app.camera;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import com.google.mlkit.vision.face.Face;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom view that draws face detection bounding boxes and landmarks
 * over the camera preview.
 */
public class FaceOverlayView extends View {

    private final Paint boxPaint;
    private final Paint textPaint;
    private final Paint cornerPaint;

    private List<Face> faces = new ArrayList<>();
    private int imageWidth = 1;
    private int imageHeight = 1;
    private boolean isFrontCamera = false;

    public FaceOverlayView(Context context) {
        this(context, null);
    }

    public FaceOverlayView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FaceOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setWillNotDraw(false);

        // Box paint
        boxPaint = new Paint();
        boxPaint.setColor(Color.argb(200, 0, 230, 120));
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(4f);
        boxPaint.setAntiAlias(true);

        // Corner accent paint
        cornerPaint = new Paint();
        cornerPaint.setColor(Color.argb(255, 0, 255, 140));
        cornerPaint.setStyle(Paint.Style.STROKE);
        cornerPaint.setStrokeWidth(8f);
        cornerPaint.setAntiAlias(true);
        cornerPaint.setStrokeCap(Paint.Cap.ROUND);

        // Text paint
        textPaint = new Paint();
        textPaint.setColor(Color.argb(220, 0, 255, 140));
        textPaint.setTextSize(36f);
        textPaint.setAntiAlias(true);
        textPaint.setFakeBoldText(true);
    }

    public void setFaces(List<Face> faces, int imageWidth, int imageHeight, boolean isFrontCamera) {
        this.faces = faces != null ? faces : new ArrayList<>();
        this.imageWidth = Math.max(imageWidth, 1);
        this.imageHeight = Math.max(imageHeight, 1);
        this.isFrontCamera = isFrontCamera;
        postInvalidate();
    }

    public void clearFaces() {
        faces = new ArrayList<>();
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (faces.isEmpty()) return;

        float scaleX = (float) getWidth()  / imageWidth;
        float scaleY = (float) getHeight() / imageHeight;

        for (Face face : faces) {
            android.graphics.Rect bounds = face.getBoundingBox();

            float left   = bounds.left   * scaleX;
            float top    = bounds.top    * scaleY;
            float right  = bounds.right  * scaleX;
            float bottom = bounds.bottom * scaleY;

            // Mirror horizontally for front camera
            if (isFrontCamera) {
                float tmp = getWidth() - left;
                left  = getWidth() - right;
                right = tmp;
            }

            RectF rect = new RectF(left, top, right, bottom);

            // Draw box
            canvas.drawRoundRect(rect, 12, 12, boxPaint);

            // Draw corner accents (like a targeting reticle)
            float cornerLen = (rect.width() * 0.22f);
            // Top-left
            canvas.drawLine(rect.left, rect.top + cornerLen, rect.left, rect.top, cornerPaint);
            canvas.drawLine(rect.left, rect.top, rect.left + cornerLen, rect.top, cornerPaint);
            // Top-right
            canvas.drawLine(rect.right - cornerLen, rect.top, rect.right, rect.top, cornerPaint);
            canvas.drawLine(rect.right, rect.top, rect.right, rect.top + cornerLen, cornerPaint);
            // Bottom-left
            canvas.drawLine(rect.left, rect.bottom - cornerLen, rect.left, rect.bottom, cornerPaint);
            canvas.drawLine(rect.left, rect.bottom, rect.left + cornerLen, rect.bottom, cornerPaint);
            // Bottom-right
            canvas.drawLine(rect.right - cornerLen, rect.bottom, rect.right, rect.bottom, cornerPaint);
            canvas.drawLine(rect.right, rect.bottom, rect.right, rect.bottom - cornerLen, cornerPaint);

            // Draw smile / eye info
            float smileProb = face.getSmilingProbability() != null ? face.getSmilingProbability() : 0;
            float leftEyeOpen = face.getLeftEyeOpenProbability() != null ? face.getLeftEyeOpenProbability() : 1;
            float rightEyeOpen = face.getRightEyeOpenProbability() != null ? face.getRightEyeOpenProbability() : 1;

            String label = (smileProb > 0.7f ? "😊 " : "") +
                           (leftEyeOpen < 0.3f || rightEyeOpen < 0.3f ? "😉 " : "") +
                           "ID:" + face.getTrackingId();
            canvas.drawText(label, left, top - 12, textPaint);
        }
    }
}

package com.bgcam.app.utils;

/** Simple process-wide recording state flag shared between Activity and Service. */
public class RecordingState {
    private static volatile boolean recording = false;

    public static boolean isRecording() { return recording; }
    public static void setRecording(boolean state) { recording = state; }
}

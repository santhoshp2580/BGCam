package com.bgcam.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bgcam.app.R;
import com.bgcam.app.databinding.ActivityMainBinding;
import com.bgcam.app.services.BackgroundRecordingService;
import com.bgcam.app.utils.PreferenceManager;
import com.bgcam.app.utils.RecordingState;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private PreferenceManager prefs;
    private static final int PERMISSION_REQUEST_CODE = 100;

    private static final String[] REQUIRED_PERMISSIONS;

    static {
        List<String> perms = new ArrayList<>();
        perms.add(Manifest.permission.CAMERA);
        perms.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
            perms.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        REQUIRED_PERMISSIONS = perms.toArray(new String[0]);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefs = new PreferenceManager(this);
        setupUI();

        if (!allPermissionsGranted()) {
            requestPermissions();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }

    private void setupUI() {
        // Open Camera (with preview)
        binding.btnOpenCamera.setOnClickListener(v -> {
            if (!allPermissionsGranted()) { requestPermissions(); return; }
            startActivity(new Intent(this, CameraActivity.class));
        });

        // Start Background Recording (screen off OK)
        binding.btnBackgroundRecord.setOnClickListener(v -> {
            if (!allPermissionsGranted()) { requestPermissions(); return; }
            if (RecordingState.isRecording()) {
                stopBackgroundRecording();
            } else {
                startBackgroundRecording();
            }
        });

        // Open Gallery
        binding.btnGallery.setOnClickListener(v ->
            startActivity(new Intent(this, GalleryActivity.class)));

        // Settings
        binding.btnSettings.setOnClickListener(v -> showSettingsDialog());

        // Camera toggle (front/back)
        binding.switchCamera.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.setUseFrontCamera(isChecked);
            binding.tvCameraLabel.setText(isChecked ? "Front Camera" : "Back Camera");
        });
        binding.switchCamera.setChecked(prefs.isUseFrontCamera());
        binding.tvCameraLabel.setText(prefs.isUseFrontCamera() ? "Front Camera" : "Back Camera");

        // Face detection toggle
        binding.switchFaceDetect.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.setFaceDetectionEnabled(isChecked);
            binding.tvFaceLabel.setText(isChecked ? "Face Detection: ON" : "Face Detection: OFF");
        });
        binding.switchFaceDetect.setChecked(prefs.isFaceDetectionEnabled());
        binding.tvFaceLabel.setText(prefs.isFaceDetectionEnabled() ? "Face Detection: ON" : "Face Detection: OFF");

        // Stabilization toggle
        binding.switchStabilization.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.setStabilizationEnabled(isChecked);
            binding.tvStabLabel.setText(isChecked ? "Stabilization: ON" : "Stabilization: OFF");
        });
        binding.switchStabilization.setChecked(prefs.isStabilizationEnabled());
        binding.tvStabLabel.setText(prefs.isStabilizationEnabled() ? "Stabilization: ON" : "Stabilization: OFF");

        // Quality selector
        binding.spinnerQuality.setSelection(prefs.getQualityIndex());
        binding.spinnerQuality.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                prefs.setQualityIndex(pos);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
    }

    private void updateUI() {
        boolean recording = RecordingState.isRecording();
        if (recording) {
            binding.btnBackgroundRecord.setText("⏹ Stop Background Recording");
            binding.btnBackgroundRecord.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.red));
            binding.tvRecordingStatus.setText("● RECORDING IN BACKGROUND");
            binding.tvRecordingStatus.setVisibility(View.VISIBLE);
        } else {
            binding.btnBackgroundRecord.setText("📹 Start Background Recording");
            binding.btnBackgroundRecord.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.green));
            binding.tvRecordingStatus.setVisibility(View.GONE);
        }
    }

    private void startBackgroundRecording() {
        Intent serviceIntent = new Intent(this, BackgroundRecordingService.class);
        serviceIntent.setAction(BackgroundRecordingService.ACTION_START);
        ContextCompat.startForegroundService(this, serviceIntent);
        Toast.makeText(this, "Background recording started. You can lock the screen.", Toast.LENGTH_LONG).show();
        updateUI();
    }

    private void stopBackgroundRecording() {
        Intent serviceIntent = new Intent(this, BackgroundRecordingService.class);
        serviceIntent.setAction(BackgroundRecordingService.ACTION_STOP);
        startService(serviceIntent);
        Toast.makeText(this, "Recording stopped. Video saved to gallery.", Toast.LENGTH_SHORT).show();
        updateUI();
    }

    private void showSettingsDialog() {
        String[] options = {"About", "Clear all recordings"};
        new AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(options, (dialog, which) -> {
                if (which == 0) showAbout();
                else confirmClearRecordings();
            }).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("BGCam v1.0")
            .setMessage("Background Video Recorder\n\n• Records in background (screen off)\n• 1080p / 720p / 480p quality\n• Video stabilization\n• Face detection overlay\n• Front & rear camera support")
            .setPositiveButton("OK", null).show();
    }

    private void confirmClearRecordings() {
        new AlertDialog.Builder(this)
            .setTitle("Clear Recordings?")
            .setMessage("This will delete all recorded videos. Are you sure?")
            .setPositiveButton("Delete", (d, w) -> {
                com.bgcam.app.utils.FileUtils.clearAllRecordings(this);
                Toast.makeText(this, "All recordings deleted", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null).show();
    }

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : results) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "All permissions are required for the app to work.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
    }
}

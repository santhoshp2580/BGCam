package com.bgcam.app.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.core.content.ContextCompat;

import com.bgcam.app.R;
import com.bgcam.app.databinding.ActivityCameraBinding;
import com.bgcam.app.utils.FileUtils;
import com.bgcam.app.utils.PreferenceManager;
import com.bgcam.app.utils.RecordingState;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraActivity extends AppCompatActivity {

    private static final String TAG = "CameraActivity";
    private ActivityCameraBinding binding;
    private PreferenceManager prefs;

    private ProcessCameraProvider cameraProvider;
    private VideoCapture<Recorder> videoCapture;
    private Recording currentRecording;
    private Camera camera;
    private FaceDetector faceDetector;
    private ExecutorService cameraExecutor;
    private boolean isRecording = false;
    private int recordingSeconds = 0;
    private CountDownTimer timerUpdater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCameraBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefs = new PreferenceManager(this);
        cameraExecutor = Executors.newSingleThreadExecutor();
        setupFaceDetector();
        setupCamera();
        setupControls();
    }

    private void setupFaceDetector() {
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.10f)
            .enableTracking()
            .build();
        faceDetector = FaceDetection.getClient(options);
    }

    private void setupCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
            ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get();
                bindCameraUseCases();
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Camera init failed", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases() {
        cameraProvider.unbindAll();

        // Camera selector (front/back)
        CameraSelector cameraSelector = prefs.isUseFrontCamera()
            ? CameraSelector.DEFAULT_FRONT_CAMERA
            : CameraSelector.DEFAULT_BACK_CAMERA;

        // Preview
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(binding.previewView.getSurfaceProvider());

        // Video capture with quality selector
        Quality selectedQuality = getSelectedQuality();
        QualitySelector qualitySelector = QualitySelector.from(
            selectedQuality,
            androidx.camera.video.FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
        );
        Recorder recorder = new Recorder.Builder()
            .setQualitySelector(qualitySelector)
            .build();
        videoCapture = VideoCapture.withOutput(recorder);

        // Face detection image analysis
        ImageAnalysis imageAnalysis = null;
        if (prefs.isFaceDetectionEnabled()) {
            imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
            imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeFaces);
        }

        try {
            if (imageAnalysis != null) {
                camera = cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, videoCapture, imageAnalysis);
            } else {
                camera = cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, videoCapture);
            }

            // Enable stabilization if supported & enabled
            if (prefs.isStabilizationEnabled()) {
                try {
                    camera.getCameraControl().setZoomRatio(1.0f);
                } catch (Exception e) {
                    Log.w(TAG, "Stabilization not available");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Camera bind failed", e);
            Toast.makeText(this, "Camera error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @SuppressWarnings("UnsafeOptInUsageError")
    private void analyzeFaces(ImageProxy imageProxy) {
        if (!prefs.isFaceDetectionEnabled()) {
            imageProxy.close();
            return;
        }
        InputImage image = InputImage.fromMediaImage(
            imageProxy.getImage(),
            imageProxy.getImageInfo().getRotationDegrees()
        );
        faceDetector.process(image)
            .addOnSuccessListener(faces -> {
                runOnUiThread(() -> drawFaceBoxes(faces, imageProxy.getWidth(), imageProxy.getHeight()));
                imageProxy.close();
            })
            .addOnFailureListener(e -> {
                imageProxy.close();
            });
    }

    private void drawFaceBoxes(List<Face> faces, int imageWidth, int imageHeight) {
        if (binding.faceOverlay == null) return;
        binding.faceOverlay.setFaces(faces, imageWidth, imageHeight,
            prefs.isUseFrontCamera());
        binding.tvFaceCount.setText(faces.isEmpty() ? "" : faces.size() + " face(s) detected");
    }

    private void setupControls() {
        // Record button
        binding.btnRecord.setOnClickListener(v -> {
            if (isRecording) stopRecording();
            else startRecording();
        });

        // Switch camera
        binding.btnSwitchCamera.setOnClickListener(v -> {
            prefs.setUseFrontCamera(!prefs.isUseFrontCamera());
            bindCameraUseCases();
        });

        // Toggle flash
        binding.btnFlash.setOnClickListener(v -> {
            if (camera != null) {
                boolean torchState = camera.getCameraInfo().getTorchState().getValue() != null
                    && camera.getCameraInfo().getTorchState().getValue() == 1;
                camera.getCameraControl().enableTorch(!torchState);
                binding.btnFlash.setImageResource(!torchState
                    ? R.drawable.ic_flash_on : R.drawable.ic_flash_off);
            }
        });

        // Face detection toggle
        binding.btnFaceDetect.setOnClickListener(v -> {
            prefs.setFaceDetectionEnabled(!prefs.isFaceDetectionEnabled());
            binding.btnFaceDetect.setAlpha(prefs.isFaceDetectionEnabled() ? 1.0f : 0.4f);
            if (!prefs.isFaceDetectionEnabled()) {
                binding.faceOverlay.clearFaces();
                binding.tvFaceCount.setText("");
            }
            bindCameraUseCases();
        });

        // Close / back
        binding.btnClose.setOnClickListener(v -> finish());

        // Update face detect button alpha
        binding.btnFaceDetect.setAlpha(prefs.isFaceDetectionEnabled() ? 1.0f : 0.4f);
    }

    private void startRecording() {
        if (videoCapture == null) return;
        File outputFile = FileUtils.createVideoFile(this);
        FileOutputOptions outputOptions = new FileOutputOptions.Builder(outputFile).build();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Audio permission required", Toast.LENGTH_SHORT).show();
            return;
        }

        currentRecording = videoCapture.getOutput()
            .prepareRecording(this, outputOptions)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this), videoRecordEvent -> {
                if (videoRecordEvent instanceof VideoRecordEvent.Start) {
                    isRecording = true;
                    RecordingState.setRecording(true);
                    updateRecordingUI(true);
                } else if (videoRecordEvent instanceof VideoRecordEvent.Finalize) {
                    VideoRecordEvent.Finalize finalizeEvent =
                        (VideoRecordEvent.Finalize) videoRecordEvent;
                    isRecording = false;
                    RecordingState.setRecording(false);
                    updateRecordingUI(false);
                    if (!finalizeEvent.hasError()) {
                        FileUtils.scanMediaFile(this, outputFile);
                        Toast.makeText(this, "Video saved: " + outputFile.getName(),
                            Toast.LENGTH_LONG).show();
                    } else {
                        Log.e(TAG, "Recording error: " + finalizeEvent.getError());
                        outputFile.delete();
                    }
                }
            });
    }

    private void stopRecording() {
        if (currentRecording != null) {
            currentRecording.stop();
            currentRecording = null;
        }
    }

    private void updateRecordingUI(boolean recording) {
        if (recording) {
            binding.btnRecord.setImageResource(R.drawable.ic_stop);
            binding.recordingIndicator.setVisibility(View.VISIBLE);
            binding.tvTimer.setVisibility(View.VISIBLE);
            recordingSeconds = 0;
            startTimer();
        } else {
            binding.btnRecord.setImageResource(R.drawable.ic_record);
            binding.recordingIndicator.setVisibility(View.GONE);
            binding.tvTimer.setVisibility(View.GONE);
            if (timerUpdater != null) timerUpdater.cancel();
        }
    }

    private void startTimer() {
        timerUpdater = new CountDownTimer(Long.MAX_VALUE, 1000) {
            @Override public void onTick(long ms) {
                recordingSeconds++;
                int h = recordingSeconds / 3600;
                int m = (recordingSeconds % 3600) / 60;
                int s = recordingSeconds % 60;
                binding.tvTimer.setText(String.format("%02d:%02d:%02d", h, m, s));
            }
            @Override public void onFinish() {}
        }.start();
    }

    private Quality getSelectedQuality() {
        int idx = prefs.getQualityIndex();
        switch (idx) {
            case 0: return Quality.HIGHEST; // 1080p / best available
            case 1: return Quality.HD;      // 720p
            case 2: return Quality.SD;      // 480p
            default: return Quality.HIGHEST;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timerUpdater != null) timerUpdater.cancel();
        if (currentRecording != null) currentRecording.stop();
        cameraExecutor.shutdown();
        faceDetector.close();
    }
}

package com.bgcam.app.utils;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.os.Environment;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FileUtils {

    private static final String VIDEO_DIR = "BGCam";

    public static File getOutputDirectory(Context context) {
        File dir;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            dir = new File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), VIDEO_DIR);
        } else {
            dir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                VIDEO_DIR
            );
        }
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File createVideoFile(Context context) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            .format(new Date());
        String fileName = "BGCam_" + timestamp + ".mp4";
        return new File(getOutputDirectory(context), fileName);
    }

    public static List<File> getAllRecordedVideos(Context context) {
        File dir = getOutputDirectory(context);
        File[] files = dir.listFiles(f -> f.getName().endsWith(".mp4"));
        if (files == null) return new ArrayList<>();
        Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return new ArrayList<>(Arrays.asList(files));
    }

    public static void scanMediaFile(Context context, File file) {
        MediaScannerConnection.scanFile(
            context,
            new String[]{file.getAbsolutePath()},
            new String[]{"video/mp4"},
            null
        );
    }

    public static void clearAllRecordings(Context context) {
        for (File f : getAllRecordedVideos(context)) {
            f.delete();
        }
    }
}
